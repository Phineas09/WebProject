#include <iostream>
#include <string>

using namespace std;


int main() {
	
	char buffer[256];
	std::cin >> buffer;
	std::cout << buffer;
	return 0;
}